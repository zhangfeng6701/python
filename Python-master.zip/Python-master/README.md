### 这是我日常遇到的一些小问题的解决办法，全部是基于Python3

1.[获取当前CPU状态，存储到Influxdb](https://github.com/injetlee/demo/blob/master/CpuToInfluxdb.py)

2.[模拟登录知乎](https://github.com/injetlee/demo/blob/master/login_zhihu.py)

3.[对目录下所有文件计数](https://github.com/injetlee/demo/blob/master/countFile.py)


4.[爬取豆瓣电影top250](https://github.com/injetlee/demo/blob/master/douban_movie.py)

5.[Excel文件读入数据库](https://github.com/injetlee/demo/blob/master/excelToDatabase.py)

6.[爬取拉勾网职位信息](https://github.com/injetlee/demo/blob/master/lagouSpider.py)

7.[批量修改文件名](https://github.com/injetlee/demo/blob/master/ModifyFilename.py)

8.[读写excel](https://github.com/injetlee/demo/blob/master/readExcel.py)

9.[下载必应首页图片,只下载当天的，一张。](https://github.com/injetlee/Python/blob/master/biyingSpider.py)

10.[Python微信公众号开发](https://github.com/injetlee/Python/tree/master/wechat)
